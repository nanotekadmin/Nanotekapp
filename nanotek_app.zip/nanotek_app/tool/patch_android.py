"""Adds the Android settings the app needs after `flutter create` generates the android/ folder.

- Internet + notification permissions
- App name "Nanotek"
- Links the app is allowed to open (phone, email, WhatsApp, maps)
- Java desugaring (required by flutter_local_notifications)

Safe to run more than once.
"""
import pathlib
import re
import sys

app = pathlib.Path("android/app")
manifest = app / "src/main/AndroidManifest.xml"
if not manifest.exists():
    sys.exit("android/ folder not found - run `flutter create` first")

s = manifest.read_text()
perms = [
    "android.permission.INTERNET",
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.VIBRATE",
]
add = "".join(f'    <uses-permission android:name="{p}"/>\n' for p in perms if p not in s)
if add:
    s = re.sub(r"(<manifest[^>]*>\s*\n)", lambda m: m.group(1) + add, s, count=1)

s = re.sub(r'android:label="[^"]*"', 'android:label="Nanotek"', s, count=1)

intents = """        <intent>
            <action android:name="android.intent.action.DIAL"/>
            <data android:scheme="tel"/>
        </intent>
        <intent>
            <action android:name="android.intent.action.SENDTO"/>
            <data android:scheme="mailto"/>
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW"/>
            <data android:scheme="https"/>
        </intent>
"""
if 'android:scheme="tel"' not in s:
    if "<queries>" in s:
        s = s.replace("<queries>", "<queries>\n" + intents, 1)
    else:
        s = s.replace("</manifest>", "    <queries>\n" + intents + "    </queries>\n</manifest>", 1)
manifest.write_text(s)
print("Patched", manifest)

kts = app / "build.gradle.kts"
groovy = app / "build.gradle"
if kts.exists():
    t = kts.read_text()
    if "isCoreLibraryDesugaringEnabled" not in t:
        if "compileOptions {" not in t:
            sys.exit("compileOptions block not found in build.gradle.kts")
        t = t.replace("compileOptions {", "compileOptions {\n        isCoreLibraryDesugaringEnabled = true", 1)
        t += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
        kts.write_text(t)
    print("Patched", kts)
elif groovy.exists():
    t = groovy.read_text()
    if "coreLibraryDesugaringEnabled" not in t:
        if "compileOptions {" not in t:
            sys.exit("compileOptions block not found in build.gradle")
        t = t.replace("compileOptions {", "compileOptions {\n        coreLibraryDesugaringEnabled true", 1)
        t += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
        groovy.write_text(t)
    print("Patched", groovy)
else:
    sys.exit("No app build.gradle found")

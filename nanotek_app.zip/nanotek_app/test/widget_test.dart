import 'package:flutter_test/flutter_test.dart';
import 'package:nanotek_app/config.dart';

void main() {
  test('all category links point to nanotek.lk', () {
    for (final c in categories) {
      expect(c.url.startsWith('https://www.nanotek.lk/category/'), isTrue);
    }
  });
}

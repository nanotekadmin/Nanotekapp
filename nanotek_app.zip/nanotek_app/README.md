# Nanotek Android App

Hybrid app for nanotek.lk. Native screens, navigation, notifications and pop-ups wrap the live website, so **login, register, cart, checkout and payments run on your real site** and always show live prices and stock.

## What's in it

| Area | What it does |
|---|---|
| Splash | Animated Nanotek logo |
| Home | Live nanotek.lk with loading bar, refresh, offline screen |
| Categories | All 31 categories, search, quick Call / Showrooms / Services / Contact, WhatsApp button |
| Product pages | Floating ♥ save-to-wishlist and copy-link buttons |
| Wishlist | Saved products (swipe to remove), opens live price |
| Alerts | Notification center: filters (Orders / Deals / Account), unread badges, swipe to delete, "turn on notifications" prompt |
| Account | Your real login page + menu (Register, Forgot password, Services, About, Careers, Contact, Showrooms, Call) |
| Showrooms | Dehiwala, Colombo 03, Kurunegala with directions + call, socials |
| Pop-ups | First-launch welcome pop-up, notification permission sheet, slide-down in-app banners, snackbars |
| Phone notifications | Order-received notification when the checkout success page loads; welcome notification; tapping opens the right page |
| Back button | Goes back inside the website first; "press back again to exit" |

Phone calls, WhatsApp, maps and social links open in their own apps. Payment gateway pages stay inside the app.

## Build the APK (no setup on your computer)

1. Create a **private** GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab → **Build Android APK**. It runs automatically on every push (or press **Run workflow**).
3. When it finishes (~8–10 min), open the run and download **nanotek-app-apk** → `app-release.apk`.
4. Copy it to an Android phone and install (allow "install unknown apps").

To build on your own computer instead (Flutter installed):

```
flutter create --platforms=android --org lk.nanotek --project-name nanotek_app .
python3 tool/patch_android.py
flutter pub get
dart run flutter_launcher_icons
flutter build apk --release
```

## Things to check / change

All store details are in `lib/config.dart` (URLs, hotline, WhatsApp number, categories, showrooms, colours).

- **WhatsApp number** – set to the hotline 94777292272. Change it if WhatsApp uses another number.
- **Order-success detection** – `lib/screens/web_tab.dart` (`_detectEvents`) fires the "Order received" notification when the URL contains order/checkout + success/thank/complete/confirm. Match it to your real thank-you page URL.
- **File uploads** (e.g. CV on Careers, bank slips) – Android WebView needs an extra file-picker hook; add it if customers upload files on the site.

## Before publishing on Google Play

1. **Marketing push notifications** (flash sales, price drops sent by you): create a Firebase project, add the Android app `lk.nanotek.nanotek_app`, and add `firebase_messaging`. Ask your web developer to send pushes when orders change status.
2. **Signing key**: the APK above is signed with a debug key (fine for testing). Play Store needs your own upload keystore.
3. **Native product screens**: for fully native product lists, search and cart, ask callmetyno.com for JSON API endpoints (products, categories, search, cart, auth, orders). The app is structured so these can replace the web pages tab by tab.

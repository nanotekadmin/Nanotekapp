import 'package:flutter/material.dart';

import 'screens/browser_screen.dart';

final navigatorKey = GlobalKey<NavigatorState>();

/// Opens any nanotek.lk page in a full-screen in-app browser.
void openPage(String url, {String? title}) {
  navigatorKey.currentState?.push(
    MaterialPageRoute(builder: (_) => BrowserScreen(url: url, title: title)),
  );
}

void toast(BuildContext context, String message) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));
}

String timeAgo(DateTime t) {
  final d = DateTime.now().difference(t);
  if (d.inMinutes < 1) return 'now';
  if (d.inMinutes < 60) return '${d.inMinutes}m ago';
  if (d.inHours < 24) return '${d.inHours}h ago';
  if (d.inDays == 1) return 'Yesterday';
  return '${d.inDays} days ago';
}

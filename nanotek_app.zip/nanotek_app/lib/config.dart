import 'package:flutter/material.dart';

/// Everything store-specific lives here, so it can be changed in one place.
class AppConfig {
  static const base = 'https://www.nanotek.lk';
  static const host = 'nanotek.lk';
  static const hotline = '+94777292272';
  static const hotlineLabel = '+94 777 292 272';

  /// WhatsApp number in international format without "+". Change if different from the hotline.
  static const whatsapp = '94777292272';

  static const loginUrl = '$base/login';
  static const registerUrl = '$base/register';
  static const forgotUrl = '$base/password/forgot';
  static const servicesUrl = '$base/services';
  static const contactUrl = '$base/contact';
  static const aboutUrl = '$base/about-us';
  static const careersUrl = '$base/careers';

  static const socials = <String, String>{
    'Facebook': 'https://www.facebook.com/nanotekcomputersolutions',
    'Instagram': 'https://www.instagram.com/nanotekcomputersolutions/',
    'YouTube': 'https://www.youtube.com/@nanotekcomputersolutions2297',
    'TikTok': 'https://www.tiktok.com/@nanotekcomputersolutions',
    'LinkedIn': 'https://www.linkedin.com/company/nanotek-computer-solutions/',
  };
}

class AppColors {
  static const red = Color(0xFFE5293E);
  static const orange = Color(0xFFFF6A3D);
  static const bg = Color(0xFF0B0D12);
  static const surface = Color(0xFF141821);
  static const surface2 = Color(0xFF1C2130);
  static const line = Color(0xFF262C3D);
  static const text = Color(0xFFF2F4F8);
  static const muted = Color(0xFF8B93A7);
  static const ok = Color(0xFF22C55E);
  static const grad = LinearGradient(
    colors: [red, orange],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class Category {
  const Category(this.name, this.slug, this.emoji);
  final String name;
  final String slug;
  final String emoji;
  String get url => '${AppConfig.base}/category/$slug';
}

const categories = <Category>[
  Category('Laptop', 'laptop', '💻'),
  Category('Graphics Card', 'graphics-card', '🎮'),
  Category('Processor', 'processor', '🧠'),
  Category('Motherboards', 'motherboards', '🔌'),
  Category('Memory (RAM)', 'memory-ram', '🧩'),
  Category('Monitors & Arms', 'monitors-monitor-arms', '🖥️'),
  Category('Apple', 'apple', '🍎'),
  Category('Console & Handheld', 'console-handheld-gaming', '🕹️'),
  Category('Phones & Tablets', 'mobile-phones-tablets', '📱'),
  Category('Storage & NAS', 'storage-nas', '💾'),
  Category('Keyboard, Mouse & Gamepad', 'keyboardmouse-gamepad-controller', '⌨️'),
  Category('Speakers & Headsets', 'speakers-headsets-ear-buds', '🎧'),
  Category('Power Supply & UPS', 'power-supply-ups-surge-protectors', '⚡'),
  Category('Cooling & Lighting', 'cooling-lighting', '❄️'),
  Category('Casings', 'casings', '🗄️'),
  Category('Gaming Chairs & Tables', 'gaming-chairs-tables', '🪑'),
  Category('Desktop Workstations', 'desktop-workstations', '🖥️'),
  Category('All in One & NUC', 'all-in-one-nuc-systems', '🖲️'),
  Category('ROG Edition 20', 'rog-edition-20-lineup', '🔥'),
  Category('PBA Systems', 'pba-systems', '🏗️'),
  Category('ASUS Agent Computer', 'asus-agent-computer', '🤖'),
  Category('Television (TV)', 'television-tv', '📺'),
  Category('Projectors', 'projectors', '📽️'),
  Category('Printers', 'printers', '🖨️'),
  Category('Graphic Tablet', 'graphic-tablet', '✏️'),
  Category('Power Banks & Bags', 'power-banks-laptop-bags-accessories', '🎒'),
  Category('Cables & Hubs', 'cables-hubs', '🔗'),
  Category('External Storage', 'external-storage', '🗂️'),
  Category('Streaming & Action Cam', 'streaming-action-camera', '📷'),
  Category('Expansion & Networking', 'expansion-cards-networking', '📡'),
  Category('OS & Software', 'os-software', '💿'),
];

class Store {
  const Store(this.name, this.address, {this.service = false});
  final String name;
  final String address;
  final bool service;
}

const stores = <Store>[
  Store('Dehiwala Showroom & Service Center', 'No 110A, Galle Road, Dehiwala-Mount Lavinia', service: true),
  Store('Colombo 03 Showroom', 'No 37, School Lane, Colombo 03'),
  Store('Kurunegala Showroom', 'No 18, Suratissa Mawatha, Kurunegala'),
];

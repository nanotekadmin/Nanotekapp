import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../config.dart';

class AppNotification {
  AppNotification({
    required this.title,
    required this.body,
    required this.type,
    required this.time,
    this.url,
    this.read = false,
  });

  final String title;
  final String body;

  /// order | deal | account | general
  final String type;
  final DateTime time;
  final String? url;
  bool read;

  Map<String, dynamic> toJson() => {
        'title': title,
        'body': body,
        'type': type,
        'time': time.toIso8601String(),
        'url': url,
        'read': read,
      };

  factory AppNotification.fromJson(Map<String, dynamic> j) => AppNotification(
        title: j['title'] as String? ?? '',
        body: j['body'] as String? ?? '',
        type: j['type'] as String? ?? 'general',
        time: DateTime.tryParse(j['time'] as String? ?? '') ?? DateTime.now(),
        url: j['url'] as String?,
        read: j['read'] as bool? ?? false,
      );
}

/// Phone notifications + the in-app notification center + in-app banners.
class NotificationService extends ChangeNotifier {
  NotificationService._();
  static final instance = NotificationService._();

  static const _key = 'notifications_v1';
  final _plugin = FlutterLocalNotificationsPlugin();
  final List<AppNotification> items = [];

  /// Emits each new notification so the app can show a slide-down banner.
  final ValueNotifier<AppNotification?> banner = ValueNotifier(null);

  /// Set by the main screen: open a page / open the notification tab.
  void Function(String url)? onOpenUrl;
  VoidCallback? onOpenCenter;

  /// URL from a notification that launched the app from closed.
  String? launchUrl;

  int get unread => items.where((n) => !n.read).length;

  Future<void> init() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    try {
      await _plugin.initialize(
        const InitializationSettings(android: android),
        onDidReceiveNotificationResponse: (r) {
          final p = r.payload;
          if (p != null && p.isNotEmpty) {
            onOpenUrl?.call(p);
          } else {
            onOpenCenter?.call();
          }
        },
      );
      final details = await _plugin.getNotificationAppLaunchDetails();
      if (details?.didNotificationLaunchApp ?? false) {
        launchUrl = details!.notificationResponse?.payload;
      }
    } catch (e) {
      debugPrint('Notification init failed: $e');
    }

    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List<dynamic>;
        items.addAll(list.map((e) => AppNotification.fromJson(e as Map<String, dynamic>)));
      } catch (_) {}
    }
    notifyListeners();
  }

  AndroidFlutterLocalNotificationsPlugin? get _android =>
      _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

  Future<bool> requestPermission() async {
    final ok = await _android?.requestNotificationsPermission();
    return ok ?? false;
  }

  Future<bool> areEnabled() async {
    final ok = await _android?.areNotificationsEnabled();
    return ok ?? false;
  }

  /// Adds a notification to the center, shows an in-app banner and,
  /// when [system] is true, also shows it in the phone's notification tray.
  Future<void> push({
    required String title,
    required String body,
    String type = 'general',
    String? url,
    bool system = false,
  }) async {
    final n = AppNotification(title: title, body: body, type: type, time: DateTime.now(), url: url);
    items.insert(0, n);
    if (items.length > 100) items.removeRange(100, items.length);
    await _save();
    notifyListeners();
    banner.value = n;

    if (system) {
      try {
        await _plugin.show(
          DateTime.now().millisecondsSinceEpoch ~/ 1000 % 100000,
          title,
          body,
          const NotificationDetails(
            android: AndroidNotificationDetails(
              'nanotek_updates',
              'Nanotek updates',
              channelDescription: 'Orders, deals and account updates',
              importance: Importance.high,
              priority: Priority.high,
              color: AppColors.red,
            ),
          ),
          payload: url,
        );
      } catch (e) {
        debugPrint('Notification show failed: $e');
      }
    }
  }

  Future<void> markRead(AppNotification n) async {
    if (n.read) return;
    n.read = true;
    await _save();
    notifyListeners();
  }

  Future<void> markAllRead() async {
    for (final n in items) {
      n.read = true;
    }
    await _save();
    notifyListeners();
  }

  Future<void> remove(AppNotification n) async {
    items.remove(n);
    await _save();
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(items.map((e) => e.toJson()).toList()));
  }
}

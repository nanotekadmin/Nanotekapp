import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SavedItem {
  SavedItem({required this.title, required this.url, required this.time});
  final String title;
  final String url;
  final DateTime time;

  Map<String, dynamic> toJson() => {'title': title, 'url': url, 'time': time.toIso8601String()};

  factory SavedItem.fromJson(Map<String, dynamic> j) => SavedItem(
        title: j['title'] as String? ?? 'Product',
        url: j['url'] as String? ?? '',
        time: DateTime.tryParse(j['time'] as String? ?? '') ?? DateTime.now(),
      );
}

/// Products the customer saved with the heart button (stored on the phone).
class WishlistService extends ChangeNotifier {
  WishlistService._();
  static final instance = WishlistService._();

  static const _key = 'wishlist_v1';
  final List<SavedItem> items = [];

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw != null) {
      try {
        final list = jsonDecode(raw) as List<dynamic>;
        items.addAll(list.map((e) => SavedItem.fromJson(e as Map<String, dynamic>)));
      } catch (_) {}
    }
    notifyListeners();
  }

  static String _norm(String url) {
    final u = Uri.tryParse(url);
    if (u == null) return url;
    var path = u.path;
    if (path.endsWith('/')) path = path.substring(0, path.length - 1);
    return '${u.host.replaceFirst('www.', '')}$path';
  }

  bool contains(String url) => items.any((e) => _norm(e.url) == _norm(url));

  /// Returns true if the item is now saved, false if it was removed.
  Future<bool> toggle(String title, String url) async {
    final existing = items.where((e) => _norm(e.url) == _norm(url)).toList();
    final bool saved;
    if (existing.isNotEmpty) {
      items.removeWhere((e) => _norm(e.url) == _norm(url));
      saved = false;
    } else {
      items.insert(0, SavedItem(title: title, url: url, time: DateTime.now()));
      saved = true;
    }
    await _save();
    notifyListeners();
    return saved;
  }

  Future<void> remove(SavedItem item) async {
    items.remove(item);
    await _save();
    notifyListeners();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(items.map((e) => e.toJson()).toList()));
  }
}

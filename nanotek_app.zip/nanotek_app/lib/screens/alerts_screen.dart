import 'package:flutter/material.dart';

import '../app_nav.dart';
import '../config.dart';
import '../services/notification_service.dart';
import '../widgets/common.dart';
import '../widgets/popups.dart';

class AlertsScreen extends StatefulWidget {
  const AlertsScreen({super.key});

  @override
  State<AlertsScreen> createState() => _AlertsScreenState();
}

class _AlertsScreenState extends State<AlertsScreen> with WidgetsBindingObserver {
  String _filter = 'all';
  bool _enabled = true;

  static const _filters = {'all': 'All', 'order': 'Orders', 'deal': 'Deals', 'account': 'Account'};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _check();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _check();
  }

  Future<void> _check() async {
    final ok = await NotificationService.instance.areEnabled();
    if (mounted) setState(() => _enabled = ok);
  }

  IconData _icon(String type) => switch (type) {
        'order' => Icons.local_shipping_rounded,
        'deal' => Icons.local_fire_department_rounded,
        'account' => Icons.person_rounded,
        _ => Icons.notifications_rounded,
      };

  Color _color(String type) => switch (type) {
        'order' => const Color(0xFF3B82F6),
        'deal' => AppColors.red,
        'account' => AppColors.ok,
        _ => AppColors.muted,
      };

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: NotificationService.instance,
      builder: (context, _) {
        final all = NotificationService.instance.items;
        final items = _filter == 'all' ? all : all.where((n) => n.type == _filter).toList();
        return Column(
          children: [
            if (!_enabled)
              Container(
                margin: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.red.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.red.withValues(alpha: 0.35)),
                ),
                child: Row(children: [
                  const Icon(Icons.notifications_off_rounded, color: AppColors.red),
                  const SizedBox(width: 12),
                  const Expanded(child: Text('Phone notifications are off', style: TextStyle(fontWeight: FontWeight.w600))),
                  TextButton(
                    onPressed: () async {
                      await showNotificationPrompt(context);
                      _check();
                    },
                    child: const Text('Turn on'),
                  ),
                ]),
              ),
            SizedBox(
              height: 46,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  for (final e in _filters.entries)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(e.value),
                        selected: _filter == e.key,
                        onSelected: (_) => setState(() => _filter = e.key),
                        showCheckmark: false,
                        selectedColor: AppColors.text,
                        backgroundColor: AppColors.surface,
                        labelStyle: TextStyle(
                          color: _filter == e.key ? AppColors.bg : AppColors.muted,
                          fontWeight: FontWeight.w600,
                        ),
                        side: const BorderSide(color: AppColors.line),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      ),
                    ),
                ],
              ),
            ),
            Expanded(
              child: items.isEmpty
                  ? const EmptyState(
                      icon: Icons.notifications_none_rounded,
                      title: 'No notifications yet',
                      text: 'Order updates, offers and account alerts will appear here.',
                    )
                  : ListView.builder(
                      itemCount: items.length,
                      itemBuilder: (context, i) {
                        final n = items[i];
                        return Dismissible(
                          key: ObjectKey(n),
                          onDismissed: (_) => NotificationService.instance.remove(n),
                          background: Container(color: AppColors.red.withValues(alpha: 0.25)),
                          child: InkWell(
                            onTap: () {
                              NotificationService.instance.markRead(n);
                              final url = n.url;
                              if (url != null && url.isNotEmpty) openPage(url);
                            },
                            child: Container(
                              color: n.read ? null : AppColors.red.withValues(alpha: 0.06),
                              padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    width: 44,
                                    height: 44,
                                    decoration: BoxDecoration(
                                      color: _color(n.type).withValues(alpha: 0.15),
                                      borderRadius: BorderRadius.circular(13),
                                    ),
                                    child: Icon(_icon(n.type), color: _color(n.type), size: 22),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(n.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                                        const SizedBox(height: 3),
                                        Text(n.body, style: const TextStyle(color: AppColors.muted, fontSize: 13, height: 1.35)),
                                        const SizedBox(height: 5),
                                        Text(timeAgo(n.time), style: const TextStyle(color: AppColors.muted, fontSize: 11)),
                                      ],
                                    ),
                                  ),
                                  if (!n.read)
                                    Container(
                                      margin: const EdgeInsets.only(top: 6, left: 8),
                                      width: 8,
                                      height: 8,
                                      decoration: const BoxDecoration(color: AppColors.red, shape: BoxShape.circle),
                                    ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        );
      },
    );
  }
}

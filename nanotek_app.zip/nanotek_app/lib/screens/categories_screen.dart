import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../app_nav.dart';
import '../config.dart';
import '../widgets/common.dart';
import 'stores_screen.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});

  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final list = categories.where((c) => c.name.toLowerCase().contains(_q.toLowerCase())).toList();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
      children: [
        TextField(
          onChanged: (v) => setState(() => _q = v),
          decoration: InputDecoration(
            hintText: 'Find a category',
            prefixIcon: const Icon(Icons.search_rounded, color: AppColors.muted),
            filled: true,
            fillColor: AppColors.surface,
            contentPadding: const EdgeInsets.symmetric(vertical: 14),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AppColors.line)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AppColors.line)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AppColors.red)),
          ),
        ),
        const SizedBox(height: 16),
        if (_q.isEmpty) ...[
          Row(
            children: [
              _Quick(Icons.call_rounded, 'Call', () => launchUrl(Uri.parse('tel:${AppConfig.hotline}'))),
              _Quick(Icons.storefront_rounded, 'Showrooms',
                  () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StoresScreen()))),
              _Quick(Icons.build_rounded, 'Services', () => openPage(AppConfig.servicesUrl, title: 'Services')),
              _Quick(Icons.mail_rounded, 'Contact', () => openPage(AppConfig.contactUrl, title: 'Contact us')),
            ],
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: const LinearGradient(colors: [Color(0xFF1D2A4A), Color(0xFF2A1530)]),
              border: Border.all(color: AppColors.line),
            ),
            child: const Row(
              children: [
                Text('🛡️', style: TextStyle(fontSize: 30)),
                SizedBox(width: 12),
                Expanded(
                  child: Text('Warranty assured · Custom orders · Islandwide home delivery',
                      style: TextStyle(fontSize: 13, height: 1.35)),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const SectionTitle('All categories'),
        ],
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: list.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 0.92,
          ),
          itemBuilder: (_, i) {
            final c = list[i];
            return Material(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(18),
              child: InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => openPage(c.url, title: c.name),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppColors.line),
                  ),
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(c.emoji, style: const TextStyle(fontSize: 30)),
                      const SizedBox(height: 8),
                      Text(
                        c.name,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11.5, height: 1.2, color: Color(0xFFCFD4DF)),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
        if (list.isEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 40),
            child: Center(child: Text('No matching category', style: TextStyle(color: AppColors.muted))),
          ),
      ],
    );
  }
}

class _Quick extends StatelessWidget {
  const _Quick(this.icon, this.label, this.onTap);
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(
            children: [
              Container(
                width: 54,
                height: 54,
                decoration: cardDecoration(radius: 16),
                child: Icon(icon, color: AppColors.red),
              ),
              const SizedBox(height: 6),
              Text(label, style: const TextStyle(fontSize: 11.5, color: AppColors.muted)),
            ],
          ),
        ),
      ),
    );
  }
}

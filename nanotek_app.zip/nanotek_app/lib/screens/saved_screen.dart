import 'package:flutter/material.dart';

import '../app_nav.dart';
import '../config.dart';
import '../services/wishlist_service.dart';
import '../widgets/common.dart';

class SavedScreen extends StatelessWidget {
  const SavedScreen({super.key, required this.onBrowse});
  final VoidCallback onBrowse;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: WishlistService.instance,
      builder: (context, _) {
        final items = WishlistService.instance.items;
        if (items.isEmpty) {
          return EmptyState(
            icon: Icons.favorite_border_rounded,
            title: 'Your wishlist is empty',
            text: 'Open any product and tap the ♥ button to save it here.',
            action: SizedBox(width: 200, child: FilledButton(onPressed: onBrowse, child: const Text('Browse products'))),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (context, i) {
            final it = items[i];
            return Dismissible(
              key: ValueKey(it.url),
              direction: DismissDirection.endToStart,
              background: Container(
                alignment: Alignment.centerRight,
                padding: const EdgeInsets.only(right: 20),
                decoration: BoxDecoration(color: AppColors.red, borderRadius: BorderRadius.circular(18)),
                child: const Icon(Icons.delete_outline_rounded),
              ),
              onDismissed: (_) {
                WishlistService.instance.remove(it);
                toast(context, 'Removed from wishlist');
              },
              child: Material(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(18),
                child: InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => openPage(it.url, title: it.title),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: AppColors.line),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(color: AppColors.surface2, borderRadius: BorderRadius.circular(14)),
                          child: const Icon(Icons.favorite_rounded, color: AppColors.red),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(it.title,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontWeight: FontWeight.w600, height: 1.3)),
                              const SizedBox(height: 4),
                              Text('Saved ${timeAgo(it.time)} · tap for live price',
                                  style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right_rounded, color: AppColors.muted),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}

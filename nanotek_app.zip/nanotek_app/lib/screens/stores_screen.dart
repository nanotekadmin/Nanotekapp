import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../app_nav.dart';
import '../config.dart';
import '../widgets/common.dart';

class StoresScreen extends StatelessWidget {
  const StoresScreen({super.key});

  void _open(String url) => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Showrooms & Contact')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
        children: [
          for (final s in stores)
            Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: cardDecoration(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Icon(Icons.storefront_rounded, color: AppColors.red, size: 20),
                    const SizedBox(width: 8),
                    Expanded(child: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15))),
                  ]),
                  const SizedBox(height: 6),
                  Text(s.address, style: const TextStyle(color: AppColors.muted, height: 1.35)),
                  if (s.service)
                    const Padding(
                      padding: EdgeInsets.only(top: 6),
                      child: Text('🔧 Service & repair center', style: TextStyle(fontSize: 12.5)),
                    ),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _open(
                            'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent('Nanotek ${s.address}')}'),
                        icon: const Icon(Icons.directions_rounded, size: 18),
                        label: const Text('Directions'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => launchUrl(Uri.parse('tel:${AppConfig.hotline}')),
                        icon: const Icon(Icons.call_rounded, size: 18),
                        label: const Text('Call'),
                      ),
                    ),
                  ]),
                ],
              ),
            ),
          const SizedBox(height: 8),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFF25D366)),
            onPressed: () => _open('https://wa.me/${AppConfig.whatsapp}'),
            icon: const Icon(Icons.chat_rounded),
            label: const Text('Chat on WhatsApp'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
            onPressed: () => openPage(AppConfig.contactUrl, title: 'Contact us'),
            icon: const Icon(Icons.mail_outline_rounded),
            label: const Text('Send us a message'),
          ),
          const SizedBox(height: 24),
          const SectionTitle('Follow Nanotek'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final e in AppConfig.socials.entries)
                ActionChip(
                  label: Text(e.key),
                  backgroundColor: AppColors.surface,
                  side: const BorderSide(color: AppColors.line),
                  onPressed: () => _open(e.value),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

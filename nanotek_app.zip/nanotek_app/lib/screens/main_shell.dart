import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../app_nav.dart';
import '../config.dart';
import '../services/notification_service.dart';
import '../widgets/common.dart';
import '../widgets/popups.dart';
import 'alerts_screen.dart';
import 'categories_screen.dart';
import 'saved_screen.dart';
import 'stores_screen.dart';
import 'web_tab.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;
  final _home = GlobalKey<WebTabState>();
  final _account = GlobalKey<WebTabState>();
  DateTime? _lastBack;

  @override
  void initState() {
    super.initState();
    final ns = NotificationService.instance;
    ns.onOpenUrl = (url) => openPage(url);
    ns.onOpenCenter = () => setState(() => _index = 3);
    WidgetsBinding.instance.addPostFrameCallback((_) => _firstRun());
  }

  Future<void> _firstRun() async {
    final pending = NotificationService.instance.launchUrl;
    if (pending != null && pending.isNotEmpty) {
      NotificationService.instance.launchUrl = null;
      openPage(pending);
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getBool('welcomed') ?? false) return;
    await prefs.setBool('welcomed', true);
    await Future<void>.delayed(const Duration(milliseconds: 900));
    if (!mounted) return;
    await showWelcomePopup(context);
  }

  Future<void> _onBack() async {
    final key = _index == 0 ? _home : (_index == 4 ? _account : null);
    if (key != null && (await key.currentState?.goBack() ?? false)) return;
    if (_index != 0) {
      setState(() => _index = 0);
      return;
    }
    final now = DateTime.now();
    if (_lastBack != null && now.difference(_lastBack!) < const Duration(seconds: 2)) {
      SystemNavigator.pop();
      return;
    }
    _lastBack = now;
    if (mounted) toast(context, 'Press back again to exit');
  }

  void _openStores() => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StoresScreen()));

  Widget _bell() => ListenableBuilder(
        listenable: NotificationService.instance,
        builder: (context, _) {
          final unread = NotificationService.instance.unread;
          return IconButton(
            tooltip: 'Notifications',
            onPressed: () => setState(() => _index = 3),
            icon: Badge(
              isLabelVisible: unread > 0,
              label: Text('$unread'),
              backgroundColor: AppColors.red,
              child: const Icon(Icons.notifications_none_rounded),
            ),
          );
        },
      );

  PreferredSizeWidget _appBar() {
    switch (_index) {
      case 0:
        return AppBar(
          title: const BrandText(),
          actions: [
            IconButton(tooltip: 'Showrooms', onPressed: _openStores, icon: const Icon(Icons.storefront_outlined)),
            _bell(),
            IconButton(
              tooltip: 'Refresh',
              onPressed: () => _home.currentState?.reload(),
              icon: const Icon(Icons.refresh_rounded),
            ),
          ],
        );
      case 1:
        return AppBar(title: const Text('Categories'), actions: [_bell()]);
      case 2:
        return AppBar(title: const Text('Wishlist'), actions: [_bell()]);
      case 3:
        return AppBar(
          title: const Text('Notifications'),
          actions: [
            TextButton(
              onPressed: () => NotificationService.instance.markAllRead(),
              child: const Text('Mark all read', style: TextStyle(color: AppColors.red)),
            ),
          ],
        );
      default:
        return AppBar(
          title: const Text('My Account'),
          actions: [
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert_rounded),
              color: AppColors.surface2,
              onSelected: (v) {
                switch (v) {
                  case 'call':
                    launchUrl(Uri.parse('tel:${AppConfig.hotline}'));
                  case 'stores':
                    _openStores();
                  default:
                    _account.currentState?.load(v);
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: AppConfig.loginUrl, child: Text('Sign in')),
                PopupMenuItem(value: AppConfig.registerUrl, child: Text('Create account')),
                PopupMenuItem(value: AppConfig.forgotUrl, child: Text('Forgot password')),
                PopupMenuDivider(),
                PopupMenuItem(value: AppConfig.servicesUrl, child: Text('Services & repairs')),
                PopupMenuItem(value: AppConfig.aboutUrl, child: Text('About Nanotek')),
                PopupMenuItem(value: AppConfig.careersUrl, child: Text('Careers')),
                PopupMenuItem(value: AppConfig.contactUrl, child: Text('Contact us')),
                PopupMenuItem(value: 'stores', child: Text('Showrooms')),
                PopupMenuItem(value: 'call', child: Text('Call ${AppConfig.hotlineLabel}')),
              ],
            ),
          ],
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _onBack();
      },
      child: Scaffold(
        appBar: _appBar(),
        body: Stack(
          children: [
            IndexedStack(
              index: _index,
              children: [
                WebTab(key: _home, url: AppConfig.base),
                const CategoriesScreen(),
                SavedScreen(onBrowse: () => setState(() => _index = 0)),
                const AlertsScreen(),
                WebTab(key: _account, url: AppConfig.loginUrl),
              ],
            ),
            const Positioned(top: 8, left: 12, right: 12, child: InAppBanner()),
          ],
        ),
        floatingActionButton: _index == 1
            ? FloatingActionButton.extended(
                heroTag: null,
                backgroundColor: const Color(0xFF25D366),
                foregroundColor: Colors.white,
                onPressed: () => launchUrl(
                  Uri.parse('https://wa.me/${AppConfig.whatsapp}'),
                  mode: LaunchMode.externalApplication,
                ),
                icon: const Icon(Icons.chat_rounded),
                label: const Text('WhatsApp us', style: TextStyle(fontWeight: FontWeight.w700)),
              )
            : null,
        bottomNavigationBar: ListenableBuilder(
          listenable: NotificationService.instance,
          builder: (context, _) {
            final unread = NotificationService.instance.unread;
            return NavigationBar(
              selectedIndex: _index,
              onDestinationSelected: (i) => setState(() => _index = i),
              destinations: [
                const NavigationDestination(
                  icon: Icon(Icons.home_outlined),
                  selectedIcon: Icon(Icons.home_rounded, color: AppColors.red),
                  label: 'Home',
                ),
                const NavigationDestination(
                  icon: Icon(Icons.grid_view_outlined),
                  selectedIcon: Icon(Icons.grid_view_rounded, color: AppColors.red),
                  label: 'Categories',
                ),
                const NavigationDestination(
                  icon: Icon(Icons.favorite_border_rounded),
                  selectedIcon: Icon(Icons.favorite_rounded, color: AppColors.red),
                  label: 'Wishlist',
                ),
                NavigationDestination(
                  icon: Badge(
                    isLabelVisible: unread > 0,
                    label: Text('$unread'),
                    backgroundColor: AppColors.red,
                    child: const Icon(Icons.notifications_none_rounded),
                  ),
                  selectedIcon: const Icon(Icons.notifications_rounded, color: AppColors.red),
                  label: 'Alerts',
                ),
                const NavigationDestination(
                  icon: Icon(Icons.person_outline_rounded),
                  selectedIcon: Icon(Icons.person_rounded, color: AppColors.red),
                  label: 'Account',
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

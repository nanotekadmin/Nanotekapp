import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../app_nav.dart';
import '../config.dart';
import '../services/notification_service.dart';
import '../services/wishlist_service.dart';
import '../widgets/popups.dart';

/// Shows a live nanotek.lk page. Login, cart and checkout all run on the
/// real website, so they work exactly as they do in the browser.
class WebTab extends StatefulWidget {
  const WebTab({super.key, required this.url, this.onUrlChanged});
  final String url;
  final ValueChanged<String>? onUrlChanged;

  @override
  State<WebTab> createState() => WebTabState();
}

class WebTabState extends State<WebTab> {
  late final WebViewController controller;
  double _progress = 0;
  bool _error = false;
  late String _current;
  String _previous = '';

  static final Set<String> _notifiedOrders = {};

  static const _externalHosts = [
    'wa.me',
    'whatsapp.com',
    'facebook.com',
    'instagram.com',
    'youtube.com',
    'youtu.be',
    'tiktok.com',
    'linkedin.com',
    'maps.google.com',
    'maps.app.goo.gl',
    'goo.gl',
  ];

  @override
  void initState() {
    super.initState();
    _current = widget.url;
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(AppColors.bg)
      ..setNavigationDelegate(NavigationDelegate(
        onProgress: (p) {
          if (mounted) setState(() => _progress = p / 100);
        },
        onPageStarted: (url) {
          if (!mounted) return;
          setState(() {
            _error = false;
            _current = url;
          });
        },
        onPageFinished: (url) {
          if (!mounted) return;
          setState(() {
            _progress = 1;
            _current = url;
          });
          widget.onUrlChanged?.call(url);
          _detectEvents(url);
        },
        onWebResourceError: (e) {
          if ((e.isForMainFrame ?? true) && mounted) setState(() => _error = true);
        },
        onNavigationRequest: (req) {
          final uri = Uri.tryParse(req.url);
          if (uri != null && _isExternal(uri)) {
            launchUrl(uri, mode: LaunchMode.externalApplication);
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
      ))
      ..loadRequest(Uri.parse(widget.url));
  }

  /// Phone calls, email, WhatsApp, maps and social apps open outside the app.
  /// Everything else (including payment gateways) stays inside.
  bool _isExternal(Uri uri) {
    if (uri.scheme != 'http' && uri.scheme != 'https') {
      return uri.scheme != 'about' && uri.scheme != 'data' && uri.scheme != 'blob' && uri.scheme != 'javascript';
    }
    final host = uri.host.toLowerCase();
    if (host.endsWith('google.com') && uri.path.startsWith('/maps')) return true;
    return _externalHosts.any((h) => host == h || host.endsWith('.$h'));
  }

  void _detectEvents(String url) {
    final l = url.toLowerCase();
    final prev = _previous.toLowerCase();
    _previous = url;

    // Order completed → notification. Adjust the keywords to match your
    // site's real order-success page URL.
    final isOrderPage = l.contains('order') || l.contains('checkout');
    final isSuccess = ['success', 'thank', 'complete', 'confirm'].any(l.contains);
    if (isOrderPage && isSuccess && _notifiedOrders.add(url)) {
      NotificationService.instance.push(
        title: 'Order received 🎉',
        body: "Thanks for shopping with Nanotek! We'll keep you updated on your order.",
        type: 'order',
        url: url,
        system: true,
      );
    }

    // Just signed in.
    final wasAuth = prev.contains('/login') || prev.contains('/register');
    final isAuth = l.contains('/login') || l.contains('/register') || l.contains('/password');
    if (wasAuth && !isAuth && l.contains(AppConfig.host)) {
      NotificationService.instance.push(
        title: 'Signed in ✓',
        body: 'Welcome to your Nanotek account.',
        type: 'account',
      );
    }
  }

  Future<bool> goBack() async {
    if (await controller.canGoBack()) {
      await controller.goBack();
      return true;
    }
    return false;
  }

  void reload() {
    setState(() => _error = false);
    controller.loadRequest(Uri.parse(_current));
  }

  void load(String url) => controller.loadRequest(Uri.parse(url));

  bool get _isProduct => (Uri.tryParse(_current)?.path ?? '').startsWith('/product/');

  Future<void> _toggleSave() async {
    final raw = await controller.getTitle() ?? 'Product';
    final title = raw.split('|').first.trim();
    final saved = await WishlistService.instance.toggle(title.isEmpty ? 'Product' : title, _current);
    if (mounted) toast(context, saved ? '❤️ Saved to your wishlist' : 'Removed from wishlist');
  }

  Future<void> _copyLink() async {
    await Clipboard.setData(ClipboardData(text: _current));
    if (mounted) toast(context, '🔗 Product link copied');
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(child: WebViewWidget(controller: controller)),
        if (_progress < 1)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: LinearProgressIndicator(
              value: _progress == 0 ? null : _progress,
              minHeight: 2.5,
              backgroundColor: Colors.transparent,
              color: AppColors.red,
            ),
          ),
        if (_error) Positioned.fill(child: OfflineView(onRetry: reload)),
        if (_isProduct && !_error)
          Positioned(
            right: 16,
            bottom: 16,
            child: ListenableBuilder(
              listenable: WishlistService.instance,
              builder: (context, _) {
                final saved = WishlistService.instance.contains(_current);
                return Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    FloatingActionButton.small(
                      heroTag: null,
                      backgroundColor: AppColors.surface2,
                      foregroundColor: AppColors.text,
                      onPressed: _copyLink,
                      child: const Icon(Icons.link_rounded),
                    ),
                    const SizedBox(height: 10),
                    FloatingActionButton(
                      heroTag: null,
                      backgroundColor: saved ? AppColors.red : AppColors.surface2,
                      foregroundColor: Colors.white,
                      onPressed: _toggleSave,
                      child: Icon(saved ? Icons.favorite_rounded : Icons.favorite_border_rounded),
                    ),
                  ],
                );
              },
            ),
          ),
      ],
    );
  }
}

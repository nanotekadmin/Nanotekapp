import 'package:flutter/material.dart';

import 'web_tab.dart';

/// Full-screen page for categories, contact, services, notification links etc.
class BrowserScreen extends StatefulWidget {
  const BrowserScreen({super.key, required this.url, this.title});
  final String url;
  final String? title;

  @override
  State<BrowserScreen> createState() => _BrowserScreenState();
}

class _BrowserScreenState extends State<BrowserScreen> {
  final _web = GlobalKey<WebTabState>();

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final nav = Navigator.of(context);
        final wentBack = await _web.currentState?.goBack() ?? false;
        if (!wentBack) nav.pop();
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.title ?? 'Nanotek', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
          actions: [
            IconButton(
              tooltip: 'Refresh',
              onPressed: () => _web.currentState?.reload(),
              icon: const Icon(Icons.refresh_rounded),
            ),
          ],
        ),
        body: WebTab(key: _web, url: widget.url),
      ),
    );
  }
}

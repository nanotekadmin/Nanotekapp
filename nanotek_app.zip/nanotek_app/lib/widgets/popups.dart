import 'dart:async';

import 'package:flutter/material.dart';

import '../config.dart';
import '../services/notification_service.dart';
import 'common.dart';

/// First-launch welcome pop-up that also asks for notification permission.
Future<void> showWelcomePopup(BuildContext context) {
  return showGeneralDialog(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'Welcome',
    barrierColor: Colors.black.withValues(alpha: 0.65),
    transitionDuration: const Duration(milliseconds: 380),
    pageBuilder: (_, __, ___) => const _WelcomeDialog(),
    transitionBuilder: (_, anim, __, child) => FadeTransition(
      opacity: anim,
      child: ScaleTransition(
        scale: CurvedAnimation(parent: anim, curve: Curves.easeOutBack),
        child: child,
      ),
    ),
  );
}

/// Bottom sheet asking to turn notifications on (used from the Alerts tab).
Future<void> showNotificationPrompt(BuildContext context) {
  return showModalBottomSheet(
    context: context,
    backgroundColor: AppColors.surface,
    showDragHandle: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (ctx) => Padding(
      padding: const EdgeInsets.fromLTRB(24, 0, 24, 28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(color: AppColors.red.withValues(alpha: 0.15), shape: BoxShape.circle),
            child: const Icon(Icons.notifications_active_rounded, color: AppColors.red, size: 34),
          ),
          const SizedBox(height: 16),
          const Text('Stay in the loop', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          const Text(
            'Get order updates, back-in-stock news and new arrivals from Nanotek.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.muted, height: 1.4),
          ),
          const SizedBox(height: 22),
          FilledButton(
            onPressed: () async {
              final nav = Navigator.of(ctx);
              await _enableNotifications(ctx);
              nav.pop();
            },
            child: const Text('Allow notifications'),
          ),
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Not now')),
        ],
      ),
    ),
  );
}

Future<void> _enableNotifications(BuildContext context) async {
  final messenger = ScaffoldMessenger.of(context);
  final ok = await NotificationService.instance.requestPermission();
  if (ok) {
    await NotificationService.instance.push(
      title: "You're all set 🎉",
      body: "We'll notify you about your orders, new arrivals and special offers.",
      type: 'account',
      system: true,
    );
  } else {
    messenger.showSnackBar(const SnackBar(
      content: Text('Notifications are off. You can turn them on later in Settings.'),
    ));
  }
}

class _WelcomeDialog extends StatelessWidget {
  const _WelcomeDialog();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Material(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(26),
          clipBehavior: Clip.antiAlias,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Stack(
                children: [
                  Container(
                    height: 170,
                    padding: const EdgeInsets.all(22),
                    decoration: const BoxDecoration(
                      gradient: RadialGradient(
                        center: Alignment(-0.6, -0.6),
                        radius: 1.4,
                        colors: [AppColors.orange, AppColors.red, Color(0xFF3A0A14)],
                      ),
                    ),
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('WELCOME', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.5, fontSize: 12)),
                        SizedBox(height: 6),
                        Text('Nanotek,\nin your pocket',
                            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, height: 1.05)),
                      ],
                    ),
                  ),
                  const Positioned(right: 18, bottom: 10, child: Text('🖥️', style: TextStyle(fontSize: 72))),
                  Positioned(
                    right: 8,
                    top: 8,
                    child: IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: const Icon(Icons.close_rounded),
                      style: IconButton.styleFrom(backgroundColor: Colors.black38),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const _Feature('🔔', 'Order updates & new-arrival alerts'),
                    const _Feature('❤️', 'Save products to your wishlist'),
                    const _Feature('🏬', '3 showrooms · islandwide delivery'),
                    const _Feature('💬', 'Chat with us on WhatsApp'),
                    const SizedBox(height: 14),
                    FilledButton(
                      onPressed: () async {
                        final nav = Navigator.of(context);
                        await _enableNotifications(context);
                        nav.pop();
                      },
                      child: const Text('Turn on notifications'),
                    ),
                    TextButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Start shopping', style: TextStyle(color: AppColors.muted)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Feature extends StatelessWidget {
  const _Feature(this.emoji, this.text);
  final String emoji;
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(children: [
          Text(emoji, style: const TextStyle(fontSize: 18)),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 14))),
        ]),
      );
}

/// Slide-down banner shown inside the app whenever a notification arrives.
class InAppBanner extends StatefulWidget {
  const InAppBanner({super.key});

  @override
  State<InAppBanner> createState() => _InAppBannerState();
}

class _InAppBannerState extends State<InAppBanner> {
  AppNotification? _n;
  bool _show = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    NotificationService.instance.banner.addListener(_onNew);
  }

  void _onNew() {
    final n = NotificationService.instance.banner.value;
    if (n == null || !mounted) return;
    setState(() {
      _n = n;
      _show = true;
    });
    _timer?.cancel();
    _timer = Timer(const Duration(seconds: 4), _hide);
  }

  void _hide() {
    if (mounted) setState(() => _show = false);
  }

  @override
  void dispose() {
    _timer?.cancel();
    NotificationService.instance.banner.removeListener(_onNew);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final n = _n;
    if (n == null) return const SizedBox.shrink();
    return IgnorePointer(
      ignoring: !_show,
      child: AnimatedSlide(
        offset: _show ? Offset.zero : const Offset(0, -1.6),
        duration: const Duration(milliseconds: 420),
        curve: _show ? Curves.easeOutBack : Curves.easeIn,
        child: AnimatedOpacity(
          opacity: _show ? 1 : 0,
          duration: const Duration(milliseconds: 250),
          child: GestureDetector(
            onTap: () {
              _hide();
              NotificationService.instance.markRead(n);
              final url = n.url;
              if (url != null && url.isNotEmpty) {
                NotificationService.instance.onOpenUrl?.call(url);
              } else {
                NotificationService.instance.onOpenCenter?.call();
              }
            },
            onVerticalDragEnd: (_) => _hide(),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.surface2,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.line),
                boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 30, offset: Offset(0, 10))],
              ),
              child: Row(
                children: [
                  const AppMark(size: 38),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Row(children: [
                          Expanded(
                            child: Text(n.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
                          ),
                          const Text('now', style: TextStyle(color: AppColors.muted, fontSize: 11)),
                        ]),
                        const SizedBox(height: 2),
                        Text(n.body,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: Color(0xFFCFD4DF), fontSize: 12.5, height: 1.3)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class OfflineView extends StatelessWidget {
  const OfflineView({super.key, required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: AppColors.bg,
      child: EmptyState(
        icon: Icons.wifi_off_rounded,
        title: "Can't reach Nanotek",
        text: 'Check your internet connection and try again.',
        action: SizedBox(
          width: 180,
          child: FilledButton.icon(
            onPressed: onRetry,
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Retry'),
          ),
        ),
      ),
    );
  }
}
